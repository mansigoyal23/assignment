$(document).ready(function(){

    //onclick delete icon Remove the box "Lorum ipsum"
    $(".delete-icon").on('click', function(){
        $(this).parents(".list-card").fadeOut( "slow", function() {
            $(this).remove();
        });
    });

    //onChange select value as Done open popup
    $('select#status').on('change', function() {
        if((this.value) == "Done"){
            $(".status-popup").removeClass("hide");
            $("body").addClass("popup-overlay");
            $(".status-popup").addClass("show");
        }
    });

    //if click yes in popup
    $(".yes-btn").on('click', function(){
        $("body").removeClass("popup-overlay");
        $(".status-popup").removeClass("show");
    });
    //if click no in popup
    $(".no-btn").on('click', function(){
        $("body").removeClass("popup-overlay");
        $(".status-popup").removeClass("show");
        $('select#status option').prop('selected', function() {
            return this.defaultSelected;
        });
    });

    //onClick hide button to hide New Actions area
    $(".hide-btn").on('click', function(){
        $(".section-show-btn").addClass("show");
        $(".new-action-wrapper").addClass("hide");
        $(".hide-btn").hide(100);
        $(".section-show-btn").addClass("show");
    });

    //onClick Show action button to show New Actions area
    $(".section-show-btn").on('click', function(){
        $(".section-show-btn").removeClass("show");
        $(".new-action-wrapper").removeClass("hide");
        $(".hide-btn").show(100);
        $(".section-show-btn").removeClass("show");
    });

    //onClick save button wait 2 sec and redirect to another page
    $('.save-btn').on('click',function(){
        $("body").addClass("popup-overlay");
        $(".delay-popup").addClass("show");
        setTimeout(function(){ $(location).attr('href', 'thanks.html'); }, 2000);
    });

});